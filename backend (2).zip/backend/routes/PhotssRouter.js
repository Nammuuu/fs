const router = require("express").Router();
const cloudinary = require("../utils/cloudinary");
const upload = require("../utils/multer");
const Userr = require("../models/user"); 


router.post("/", upload.single("image"), async (req, res) => {
  try {
    // Upload image to cloudinary
    const result = await cloudinary.uploader.upload(req.file);
     // Create new user
    // let user = new Userr({
    //   name: req.body.name,
    //   avatar: result.secure_url,
    //   cloudinary_id: result.public_id,
    // });
    // Save user
    // await userr.save();
    res.json(result);
    // res.json(user);
  } catch (err) {
    console.log(err);
  }}); 

module.exports = router;

