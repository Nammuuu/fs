const express = require("express");
const {
    UploadConllroler,
    deleteUpload,
    getAllUploads,   

    // updateimagefororders,
  } = require("../controller/UploadConllers.js");

  const router = express.Router();


  router
  .route("/upload/:id")
//   .put( UploadConllroler,)
//   .delete(deleteProduct)
.delete(deleteUpload)
//   .get(deleteUpload);

  router
  .route("/upload/new")
  .post(UploadConllroler);

  router.route("/p").get(getAllUploads);
  
  module.exports = router;