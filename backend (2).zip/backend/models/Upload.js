const mongoose = require("mongoose");

const UploadSchema = new mongoose.Schema({
    name:{ 
        type:String,
        required:[true, "Please enter a name of a product"],
        trim: true,
        maxLength:[20, "Product name not exceed than 20 characters"]
    },
    images:[
        {
            public_id:{
                type:String,
                required:true,
            },
            url:{
                type:String,
                required:true,
            },
        }
    ],

    

  createAt:{
      type:Date,
      default: Date.now()
  }
})
 
module.exports = mongoose.model("upload",UploadSchema);